//$("<style type='text/css'> .{display: block !important;} </style>").appendTo("head");
$(".ng-hide").removeClass("ng-hide")